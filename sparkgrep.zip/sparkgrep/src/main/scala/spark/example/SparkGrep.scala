package spark-grep.example

/**
 * Created by oventura on 10/30/15.
 */
import org.apache.spark.{SparkConf, SparkContext}


object SparkGrep {
	def main() {

		val conf = new SparkConf().setAppName("SparkGrep")
		val sc = new SparkContext(conf)
		val inputFile = sc.textFile("Readme")
		val matchTerm : String = "a"
		val numMatches = inputFile.filter(line => line.contains(matchTerm)).count()
		println("%s lines in %s contain %s".format(numMatches, args(1), matchTerm))
		System.exit(0)
	}
}
